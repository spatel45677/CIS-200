﻿namespace Prog2
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.name_label = new System.Windows.Forms.Label();
            this.address_label = new System.Windows.Forms.Label();
            this.city_label = new System.Windows.Forms.Label();
            this.state_label = new System.Windows.Forms.Label();
            this.zip_label = new System.Windows.Forms.Label();
            this.ok_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.name_textbox = new System.Windows.Forms.TextBox();
            this.address_textbox = new System.Windows.Forms.TextBox();
            this.address2_textbox = new System.Windows.Forms.TextBox();
            this.city_textbox = new System.Windows.Forms.TextBox();
            this.zip_textbox = new System.Windows.Forms.TextBox();
            this.state_combo_box = new System.Windows.Forms.ComboBox();
            this.errorProviderAll = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderAll)).BeginInit();
            this.SuspendLayout();
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Location = new System.Drawing.Point(124, 45);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(38, 13);
            this.name_label.TabIndex = 0;
            this.name_label.Text = "Name:";
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Location = new System.Drawing.Point(114, 71);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(48, 13);
            this.address_label.TabIndex = 1;
            this.address_label.Text = "Address:";
            // 
            // city_label
            // 
            this.city_label.AutoSize = true;
            this.city_label.Location = new System.Drawing.Point(135, 123);
            this.city_label.Name = "city_label";
            this.city_label.Size = new System.Drawing.Size(27, 13);
            this.city_label.TabIndex = 2;
            this.city_label.Text = "City:";
            // 
            // state_label
            // 
            this.state_label.AutoSize = true;
            this.state_label.Location = new System.Drawing.Point(127, 149);
            this.state_label.Name = "state_label";
            this.state_label.Size = new System.Drawing.Size(35, 13);
            this.state_label.TabIndex = 3;
            this.state_label.Text = "State:";
            // 
            // zip_label
            // 
            this.zip_label.AutoSize = true;
            this.zip_label.Location = new System.Drawing.Point(137, 176);
            this.zip_label.Name = "zip_label";
            this.zip_label.Size = new System.Drawing.Size(25, 13);
            this.zip_label.TabIndex = 4;
            this.zip_label.Text = "Zip:";
            // 
            // ok_button
            // 
            this.ok_button.Location = new System.Drawing.Point(103, 224);
            this.ok_button.Name = "ok_button";
            this.ok_button.Size = new System.Drawing.Size(75, 23);
            this.ok_button.TabIndex = 5;
            this.ok_button.Text = "OK";
            this.ok_button.UseVisualStyleBackColor = true;
            this.ok_button.Click += new System.EventHandler(this.Ok_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(193, 224);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 6;
            this.cancel_button.Text = "Cancel";
            this.cancel_button.UseVisualStyleBackColor = true;
            // 
            // name_textbox
            // 
            this.name_textbox.Location = new System.Drawing.Point(168, 42);
            this.name_textbox.Name = "name_textbox";
            this.name_textbox.Size = new System.Drawing.Size(100, 20);
            this.name_textbox.TabIndex = 7;
            this.name_textbox.Validating += new System.ComponentModel.CancelEventHandler(this.Name_textbox_Validating);
            this.name_textbox.Validated += new System.EventHandler(this.Name_textbox_Validated);
            // 
            // address_textbox
            // 
            this.address_textbox.Location = new System.Drawing.Point(168, 68);
            this.address_textbox.Name = "address_textbox";
            this.address_textbox.Size = new System.Drawing.Size(100, 20);
            this.address_textbox.TabIndex = 8;
            this.address_textbox.Validating += new System.ComponentModel.CancelEventHandler(this.Address_textbox_Validating);
            this.address_textbox.Validated += new System.EventHandler(this.Address_textbox_Validated);
            // 
            // address2_textbox
            // 
            this.address2_textbox.Location = new System.Drawing.Point(168, 94);
            this.address2_textbox.Name = "address2_textbox";
            this.address2_textbox.Size = new System.Drawing.Size(100, 20);
            this.address2_textbox.TabIndex = 9;
            // 
            // city_textbox
            // 
            this.city_textbox.Location = new System.Drawing.Point(168, 120);
            this.city_textbox.Name = "city_textbox";
            this.city_textbox.Size = new System.Drawing.Size(100, 20);
            this.city_textbox.TabIndex = 10;
            this.city_textbox.Validating += new System.ComponentModel.CancelEventHandler(this.City_textbox_Validating);
            this.city_textbox.Validated += new System.EventHandler(this.City_textbox_Validated);
            // 
            // zip_textbox
            // 
            this.zip_textbox.Location = new System.Drawing.Point(168, 173);
            this.zip_textbox.Name = "zip_textbox";
            this.zip_textbox.Size = new System.Drawing.Size(100, 20);
            this.zip_textbox.TabIndex = 12;
            this.zip_textbox.Validating += new System.ComponentModel.CancelEventHandler(this.Zip_textbox_Validating);
            this.zip_textbox.Validated += new System.EventHandler(this.Zip_textbox_Validated);
            // 
            // state_combo_box
            // 
            this.state_combo_box.FormattingEnabled = true;
            this.state_combo_box.Items.AddRange(new object[] {
            "KY",
            "GA",
            "NY",
            "CA",
            "FL"});
            this.state_combo_box.Location = new System.Drawing.Point(168, 146);
            this.state_combo_box.Name = "state_combo_box";
            this.state_combo_box.Size = new System.Drawing.Size(100, 21);
            this.state_combo_box.TabIndex = 13;
            this.state_combo_box.Validating += new System.ComponentModel.CancelEventHandler(this.State_combo_box_Validating);
            this.state_combo_box.Validated += new System.EventHandler(this.State_combo_box_Validated);
            // 
            // errorProviderAll
            // 
            this.errorProviderAll.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 356);
            this.Controls.Add(this.state_combo_box);
            this.Controls.Add(this.zip_textbox);
            this.Controls.Add(this.city_textbox);
            this.Controls.Add(this.address2_textbox);
            this.Controls.Add(this.address_textbox);
            this.Controls.Add(this.name_textbox);
            this.Controls.Add(this.cancel_button);
            this.Controls.Add(this.ok_button);
            this.Controls.Add(this.zip_label);
            this.Controls.Add(this.state_label);
            this.Controls.Add(this.city_label);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.name_label);
            this.Name = "AddressForm";
            this.Text = "AddressForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderAll)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label address_label;
        private System.Windows.Forms.Label city_label;
        private System.Windows.Forms.Label state_label;
        private System.Windows.Forms.Label zip_label;
        private System.Windows.Forms.Button ok_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.TextBox name_textbox;
        private System.Windows.Forms.TextBox address_textbox;
        private System.Windows.Forms.TextBox address2_textbox;
        private System.Windows.Forms.TextBox city_textbox;
        private System.Windows.Forms.TextBox zip_textbox;
        private System.Windows.Forms.ComboBox state_combo_box;
        private System.Windows.Forms.ErrorProvider errorProviderAll;
    }
}