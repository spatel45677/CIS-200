﻿namespace Prog2
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.origin_address_label = new System.Windows.Forms.Label();
            this.destination_address_label = new System.Windows.Forms.Label();
            this.fixed_cost_label = new System.Windows.Forms.Label();
            this.fixed_cost_textbox = new System.Windows.Forms.TextBox();
            this.destination_address_combo_box = new System.Windows.Forms.ComboBox();
            this.origin_address_combo_box = new System.Windows.Forms.ComboBox();
            this.ok_button = new System.Windows.Forms.Button();
            this.cancel_button = new System.Windows.Forms.Button();
            this.letterErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.letterErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // origin_address_label
            // 
            this.origin_address_label.AutoSize = true;
            this.origin_address_label.Location = new System.Drawing.Point(109, 69);
            this.origin_address_label.Name = "origin_address_label";
            this.origin_address_label.Size = new System.Drawing.Size(78, 13);
            this.origin_address_label.TabIndex = 0;
            this.origin_address_label.Text = "Origin Address:";
            // 
            // destination_address_label
            // 
            this.destination_address_label.AutoSize = true;
            this.destination_address_label.Location = new System.Drawing.Point(83, 96);
            this.destination_address_label.Name = "destination_address_label";
            this.destination_address_label.Size = new System.Drawing.Size(104, 13);
            this.destination_address_label.TabIndex = 1;
            this.destination_address_label.Text = "Destination Address:";
            // 
            // fixed_cost_label
            // 
            this.fixed_cost_label.AutoSize = true;
            this.fixed_cost_label.Location = new System.Drawing.Point(128, 123);
            this.fixed_cost_label.Name = "fixed_cost_label";
            this.fixed_cost_label.Size = new System.Drawing.Size(59, 13);
            this.fixed_cost_label.TabIndex = 2;
            this.fixed_cost_label.Text = "Fixed Cost:";
            // 
            // fixed_cost_textbox
            // 
            this.fixed_cost_textbox.Location = new System.Drawing.Point(193, 120);
            this.fixed_cost_textbox.Name = "fixed_cost_textbox";
            this.fixed_cost_textbox.Size = new System.Drawing.Size(121, 20);
            this.fixed_cost_textbox.TabIndex = 3;
            this.fixed_cost_textbox.Validating += new System.ComponentModel.CancelEventHandler(this.Fixed_cost_textbox_Validating);
            this.fixed_cost_textbox.Validated += new System.EventHandler(this.Fixed_cost_textbox_Validated);
            // 
            // destination_address_combo_box
            // 
            this.destination_address_combo_box.FormattingEnabled = true;
            this.destination_address_combo_box.Location = new System.Drawing.Point(193, 93);
            this.destination_address_combo_box.Name = "destination_address_combo_box";
            this.destination_address_combo_box.Size = new System.Drawing.Size(121, 21);
            this.destination_address_combo_box.TabIndex = 4;
            this.destination_address_combo_box.Validating += new System.ComponentModel.CancelEventHandler(this.Destination_address_combo_box_Validating);
            this.destination_address_combo_box.Validated += new System.EventHandler(this.Destination_address_combo_box_Validated);
            // 
            // origin_address_combo_box
            // 
            this.origin_address_combo_box.FormattingEnabled = true;
            this.origin_address_combo_box.Location = new System.Drawing.Point(193, 66);
            this.origin_address_combo_box.Name = "origin_address_combo_box";
            this.origin_address_combo_box.Size = new System.Drawing.Size(121, 21);
            this.origin_address_combo_box.TabIndex = 5;
            this.origin_address_combo_box.Validating += new System.ComponentModel.CancelEventHandler(this.Origin_address_combo_box_Validating);
            this.origin_address_combo_box.Validated += new System.EventHandler(this.Origin_address_combo_box_Validated);
            // 
            // ok_button
            // 
            this.ok_button.Location = new System.Drawing.Point(112, 187);
            this.ok_button.Name = "ok_button";
            this.ok_button.Size = new System.Drawing.Size(75, 23);
            this.ok_button.TabIndex = 6;
            this.ok_button.Text = "OK";
            this.ok_button.UseVisualStyleBackColor = true;
            this.ok_button.Click += new System.EventHandler(this.Ok_button_Click);
            // 
            // cancel_button
            // 
            this.cancel_button.Location = new System.Drawing.Point(239, 187);
            this.cancel_button.Name = "cancel_button";
            this.cancel_button.Size = new System.Drawing.Size(75, 23);
            this.cancel_button.TabIndex = 7;
            this.cancel_button.Text = "Cancel";
            this.cancel_button.UseVisualStyleBackColor = true;
            this.cancel_button.Click += new System.EventHandler(this.Cancel_button_Click);
            // 
            // letterErrorProvider
            // 
            this.letterErrorProvider.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 294);
            this.Controls.Add(this.cancel_button);
            this.Controls.Add(this.ok_button);
            this.Controls.Add(this.origin_address_combo_box);
            this.Controls.Add(this.destination_address_combo_box);
            this.Controls.Add(this.fixed_cost_textbox);
            this.Controls.Add(this.fixed_cost_label);
            this.Controls.Add(this.destination_address_label);
            this.Controls.Add(this.origin_address_label);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            ((System.ComponentModel.ISupportInitialize)(this.letterErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label origin_address_label;
        private System.Windows.Forms.Label destination_address_label;
        private System.Windows.Forms.Label fixed_cost_label;
        private System.Windows.Forms.TextBox fixed_cost_textbox;
        private System.Windows.Forms.ComboBox destination_address_combo_box;
        private System.Windows.Forms.ComboBox origin_address_combo_box;
        private System.Windows.Forms.Button ok_button;
        private System.Windows.Forms.Button cancel_button;
        private System.Windows.Forms.ErrorProvider letterErrorProvider;
    }
}