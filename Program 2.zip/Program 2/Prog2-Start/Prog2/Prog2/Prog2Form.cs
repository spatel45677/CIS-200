﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv;
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

            upv.AddAddress("Jeff Avery", "4785 Pick Street",
                "Appt# 101", "Telluride", "CO", 81435); // Test Address 1
            upv.AddAddress("Earnestine Carlson", "2032 Hall Valley Drive",
                "", "Logan", "WV", 25601); // Test Address 2
            upv.AddAddress("Lawrence Collins", "4498 Liberty Street",
                "Appt # 204", "Dallas", "TX", 75247); // Test Address 3
            upv.AddAddress("Marvin Kreutzer", "1285 Conaway Street",
                "Appt# 244", "Petersburg", "IN", 47567); // Test Address 4
            upv.AddAddress("Babara Williams", "4384 Andell Road",
                "", "Columbus", "OH", 43215); // Test Address 5
            upv.AddAddress("Dawn Orem", "681 Randolp Street",
                "", "Marion", "MA", 02738); // Test Address 6
            upv.AddAddress("Captain Robert Crunch", "21 Cereal Rd.", "Room 987",
                "Bethesda", "MD", 20810); // Test Address 7
            upv.AddAddress("Vlad Dracula", "6543 Vampire Way", "Apt. 1",
                "Bloodsucker City", "TN", 37210); // Test Address 8

            upv.AddLetter(upv.AddressAt(0), upv.AddressAt(1), 3.95M); 
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(3), 4.25M); 
            upv.AddGroundPackage(upv.AddressAt(4), upv.AddressAt(5), 12, 51, 65, 19.5); 
            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 8, 1.5, 17, 20); 
            upv.AddNextDayAirPackage(upv.AddressAt(0), upv.AddressAt(2), 2, 5, 1, 8, 7); 
            upv.AddNextDayAirPackage(upv.AddressAt(2), upv.AddressAt(4), 9, 6, 5, 5, 5); 
            upv.AddNextDayAirPackage(upv.AddressAt(1), upv.AddressAt(6), 10, 5, 5, 15, 5); 
            upv.AddTwoDayAirPackage(upv.AddressAt(4), upv.AddressAt(6), 49, 80, 28, 86, TwoDayAirPackage.Delivery.Saver); 
            upv.AddTwoDayAirPackage(upv.AddressAt(7), upv.AddressAt(0), 16, 16.1, 6, 90, TwoDayAirPackage.Delivery.Early); 
            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(3), 18, 19, 8, 5.5, TwoDayAirPackage.Delivery.Saver); 

        }

        List<Address> addresses = new List<Address>();    // List of test address

        List<Parcel> parcels = new List<Parcel>();         // List of test parcels


        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = System.Environment.NewLine;

            string aboutString = $"Program 2{NL}By: M1633{NL}CIS 200{NL}Fall 2019";

            MessageBox.Show(aboutString);
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Prog2.AddressForm addressForm = new Prog2.AddressForm();

            DialogResult addressResult;

            addressResult = addressForm.ShowDialog();

        }

        private void LetterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Prog2.LetterForm letterForm = new Prog2.LetterForm();

            DialogResult letterResult;

            letterResult = letterForm.ShowDialog();
        }

        private void ListAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder();

            foreach (Address address in addresses)
            {
                report.Text = address.ToString();

            }

          
        }

        private void ListParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder();

            foreach (Parcel parcel in parcels)
            {
                report.Text = parcel.ToString();

            }

            
        }
    }
}
