﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {
        public LetterForm()
        {
            InitializeComponent();
        }

        private void Ok_button_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        private void Cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void Origin_address_combo_box_Validating(object sender, CancelEventArgs e)
        {
            if (origin_address_combo_box.SelectedIndex < 0)
            {
                e.Cancel = true;
                origin_address_combo_box.Focus();
                letterErrorProvider.SetError(origin_address_combo_box, "Must select an origin address.");
            }
            else if (origin_address_combo_box.SelectedIndex == origin_address_combo_box.SelectedIndex)
            {
                e.Cancel = true;
                origin_address_combo_box.Focus();
                letterErrorProvider.SetError(origin_address_combo_box, "Origin and destination address can not be the same.");
            }
        }

        private void Origin_address_combo_box_Validated(object sender, EventArgs e)
        {
            letterErrorProvider.SetError(origin_address_combo_box, "");
        }




        private void Destination_address_combo_box_Validating(object sender, CancelEventArgs e)
        {
            if (destination_address_combo_box.SelectedIndex < 0)
            {
                e.Cancel = true;
                destination_address_combo_box.Focus();
                letterErrorProvider.SetError(destination_address_combo_box, "Must select a destination address.");
            }
            else if (destination_address_combo_box.SelectedIndex == origin_address_combo_box.SelectedIndex)
            {
                e.Cancel = true;
                destination_address_combo_box.Focus();
                letterErrorProvider.SetError(destination_address_combo_box, "Origin and destination address can not be the same.");
            }
        }

        private void Destination_address_combo_box_Validated(object sender, EventArgs e)
        {
            letterErrorProvider.SetError(destination_address_combo_box, "");
        }




        private void Fixed_cost_textbox_Validating(object sender, CancelEventArgs e)
        {
            decimal number; //Variable to hold fixed cost

            if (!decimal.TryParse(fixed_cost_textbox.Text, out number))
            {
                e.Cancel = true;
                fixed_cost_textbox.SelectAll();
                letterErrorProvider.SetError(fixed_cost_textbox, "Please enter a valid cost.");
            }
            else if (number <= 0)
            {
                e.Cancel = true;
                fixed_cost_textbox.SelectAll();
                letterErrorProvider.SetError(fixed_cost_textbox, "Fixed cost must be greater than or equal to zero.");
            }
        }

        private void Fixed_cost_textbox_Validated(object sender, EventArgs e)
        {
            letterErrorProvider.SetError(fixed_cost_textbox, "");
        }

        public int OriginIndex
        {
            //Precondition: None
            //Postcondition: Origin Address is returned
            get { return origin_address_combo_box.SelectedIndex; }

            //Precondition: None
            //Postcondition: Origin Address is set to value
            set { origin_address_combo_box.SelectedIndex = value; }

        }


        public int DestIndex
        {
            //Precondition: None
            //Postcondition: Destination Address is returned
            get { return destination_address_combo_box.SelectedIndex; }

            //Precondition: None
            //Postcondition: Destination address is set to value
            set { destination_address_combo_box.SelectedIndex = value; }
        }

       
        public string LetterFixedCost
        {
            //Precondition: None
            //Postcondition: Fixed cost is returned
            get { return fixed_cost_textbox.Text; }

            //Precondition: None
            //Postcondition: Fixed cost is set to value.
            set { fixed_cost_textbox.Text = value; }
        }


    }
}
