﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        const int MIN_ZIP = 00000;
        const int MAX_ZIP = 99999;

        public AddressForm()
        {
            InitializeComponent();

            state_combo_box.Items.Add("KY");
            state_combo_box.Items.Add("TN");
            state_combo_box.Items.Add("CA");
            state_combo_box.Items.Add("GA");
            state_combo_box.Items.Add("OH");
            state_combo_box.Items.Add("NY");

        }
       
        private void Ok_button_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;

        }

        private void Cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Name_textbox_Validated(object sender, EventArgs e)
        {
            errorProviderAll.SetError(name_textbox, "");
        }

        private void Name_textbox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(name_textbox.Text))
            {
                e.Cancel = true;
                name_textbox.Focus();
                errorProviderAll.SetError(name_textbox, "Name can not be blank.");
            }
        }



        private void Address_textbox_Validating(object sender, CancelEventArgs e)
        {
            //Address validation
            if (string.IsNullOrEmpty(address_textbox.Text))
            {
                e.Cancel = true;
                address_textbox.Focus();
                errorProviderAll.SetError(address_textbox, "Address can not be blank.");
            }
        }

        private void Address_textbox_Validated(object sender, EventArgs e)
        {
            errorProviderAll.SetError(address_textbox, "");
        }



        private void City_textbox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(city_textbox.Text))
            {
                e.Cancel = true;
                city_textbox.Focus();
                errorProviderAll.SetError(city_textbox, "City can not be blank.");
            }
        }

        private void City_textbox_Validated(object sender, EventArgs e)
        {
            errorProviderAll.SetError(city_textbox, "");
        }



        private void State_combo_box_Validating(object sender, CancelEventArgs e)
        {
            if (state_combo_box.SelectedIndex < 0)
            {
                e.Cancel = true;
                state_combo_box.Focus();
                errorProviderAll.SetError(state_combo_box, "Must select a state.");
            }
        }

        private void State_combo_box_Validated(object sender, EventArgs e)
        {
            errorProviderAll.SetError(state_combo_box, "");
        }



        private void Zip_textbox_Validating(object sender, CancelEventArgs e)
        {
            int number; //Variable to hold zip

            if (!int.TryParse(zip_textbox.Text, out number))
            {
                e.Cancel = true;
                zip_textbox.SelectAll();
                errorProviderAll.SetError(zip_textbox, "Please enter an integer.");
            }
            else if (number <= MIN_ZIP || number >= MAX_ZIP)
            {
                e.Cancel = true;
                zip_textbox.SelectAll();
                errorProviderAll.SetError(zip_textbox, "Zip must be between 00000 and 99999");
            }
        }

        private void Zip_textbox_Validated(object sender, EventArgs e)
        {
            errorProviderAll.SetError(zip_textbox, "");
        }

        internal string AddressName
        {
            //Precondition: None
            //Postcondition: Returns name
            get { return name_textbox.Text; }

            //Precondition: None
            //Postcondition: Sets name to value
            set { name_textbox.Text = value; }
        }

        internal string AddressLine1
        {
            //Precondition: None
            //Postcondition: Returns address line 1
            get { return address_textbox.Text; }

            //Precondition: None
            //Postcondition: Set value to address line 1
            set { address_textbox.Text = value; }
        }

        internal string AddressLine2
        {
            //Precondition: None
            //Postcondition: Returns address line 2
            get { return address2_textbox.Text; }

            //Precondition: None
            //Postcondition: Sets value to address line 2
            set { address2_textbox.Text = value; }
        }

        internal string AddressCity
        {
            //Precondition: None
            //Postcondition: Returns city
            get { return city_textbox.Text; }

            //Precondition: None
            //Postcondition: Sets value to city
            set { city_textbox.Text = value; }
        }

        internal string AddressState
        {
            //Precondition: None
            //Postcondition: Returns state
            get { return state_combo_box.Text; }

            //Precondition: None
            //Postcondition: Sets value to state
            set { state_combo_box.Text = value; }
        }

        internal string AddressZip
        {
            //Precondition: None
            //Postcondition: Returns zip code
            get { return zip_textbox.Text; }

            //Precondition: None
            //Postcondition: Sets value to zip
            set { zip_textbox.Text = value; }
        }

    }
}
