﻿// Program 4
// CIS 200-01
// Fall 2019
// Due: 11/25/19
// By: M1633
// This is a class for sort by Destination Zipcode(Descending)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescendingZipCode : Comparer<Parcel>
    {
        //Precondition: None
        //Postcondition: Sorts parcels by destination zipcode(Descending)
        public override int Compare(Parcel parcel1, Parcel parcel2)
        {
            // Ensure correct handling of null values
            if (parcel1 == null && parcel2 == null)// Both null
            { return 0; }

            if (parcel1 == null) // only parcel1 is null
            { return -1; }

            if (parcel2 == null)// only parcel2 is null
            { return 1; }

            // Reverses natural order by using -1, so it will be descending
            return (-1) * parcel1.DestinationAddress.Zip.CompareTo(parcel2.DestinationAddress.Zip);
        }
    }
}
