﻿// Program 4
// CIS 200-01
// Fall 2019
// Due: 11/25/19
// By: M1633
// This is a class for sort by Type(Ascending) and then Cost(Descending)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class AscTypeDescCost : Comparer<Parcel>
    {
        // Precondition: None
        // Postcondition: Sort parcels by Type(Ascending) and then by Cost(Descending)
        public override int Compare(Parcel parcel1, Parcel parcel2)
        {
            string p1; // string declaration
            string p2; // string declaration

            // Ensure correct handling of null values
            if (parcel1 == null && parcel2 == null) // Both null
            { return 0; }

            if (parcel1 == null) // only parcel1 is null
            { return -1; }

            if (parcel2 == null) // only parcel2 is null
            { return 1; }

            p1 = parcel1.GetType().ToString();
            p2 = parcel2.GetType().ToString();

            if (p1 == p2) // if they are same type
                // Reverses natural order by using -1, so it will be descending
                return (-1) * parcel1.CalcCost().CompareTo(parcel2.CalcCost()); 
            

            return p1.CompareTo(p2);
        }
    }
}
