﻿//Grading ID - M1633
// Program 1B
// CIS 200-01
// Due: 10/02/2019

// Simple test program for initial Parcel classes which creates different report using LINQ

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Barbara Nelson", "3112 Cemetery Street", "Glenwood", "FL", 32722);// Test Address 5
            Address a6 = new Address("Charles Longley", "2526 Cunningham Court", "Cresson", "PA", 16630);// Test Address 6
            Address a7 = new Address("Gaye Timmons", "3668 Polk Street", "Tucson", "AZ", 85706);// Test Address 7
            Address a8 = new Address("Julia Robinson", "1769 Post Farm Road", "Atlanta", "GA", 30309);// Test Address 8

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a7, a5, 3.21M);                            // Letter test object

            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a6, a8, 19, 14, 2, 40);        // Ground test object

            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a5, a6, 29, 32, 9,    // Next Day test object
                90, 5.50M);

            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a7, a8, 51.5, 12.5, 69, // Two Day test object
                92, TwoDayAirPackage.Delivery.Early);

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(tdap1);
            parcels.Add(tdap2);

            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            // Used LINQ to select all parcels and order by destination zip code in descending order.
            var destZipDescending = 
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            WriteLine("Destination Zip(descending) Report:");
            WriteLine("=====================================");
            foreach (Parcel p in destZipDescending)
            {
                WriteLine(p);
                WriteLine("=================================");
            }
            Pause();

            // Used LINQ to select all parcels and order by cost in Ascending order.
            var costAscending =
                from p in parcels
                orderby p.CalcCost() ascending
                select p;
            WriteLine("Cost(Ascending) Report:");
            WriteLine("=====================================");
            foreach (Parcel p in costAscending)
            {
                WriteLine(p);
                WriteLine("=================================");
            }
            Pause();

            // Used LINQ to select all parcels and order by parcel type and cost in Ascending and descending order.
            var parcelTypeAndCost =
                from p in parcels
                orderby p.GetType().ToString() ascending, p.CalcCost() descending
                select p;
            WriteLine("Parcel Type And Cost Report:");
            WriteLine("=====================================");
            foreach (Parcel p in parcelTypeAndCost)
            {
                WriteLine(p);
                WriteLine("=================================");
            }
            Pause();

            // Used LINQ to select all parcels and order by Parcel type and weight in descending order.
            var airPackageHeavyAndWeight =
                from p in parcels
                where p is AirPackage && ((AirPackage)p).IsHeavy() == true
                orderby ((AirPackage)p).Weight descending
                select p;
            WriteLine("Air Package and Weight Report:");
            WriteLine("=====================================");
            foreach (Parcel p in airPackageHeavyAndWeight)
            {
                WriteLine(p);
                WriteLine("=================================");
            }
            Pause();


        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
