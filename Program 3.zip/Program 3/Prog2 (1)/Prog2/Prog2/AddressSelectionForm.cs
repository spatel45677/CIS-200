﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UPVApp;

namespace Prog2
{
    public partial class Address_Selection_Form : Form
    {
        private List<Address> addressList;
        public int index;

        public static int addressIndex { get; internal set; }

        public Address_Selection_Form(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
            foreach (Address var in addressList)
            {
                address_Selection_Combo.Items.Add(var.Name.ToString());
            }
        }

        internal int Address_Index
        {
            // Precondition:  User has selected from the ComboBox
            // Postcondition: The index of the address returned
            get
            {
                return address_Selection_Combo.SelectedIndex;
            }
            // Precondition:  -1 <= value and value < addressList.Count
            // Postcondition: The specified index is selected
            set
            {
                if ((value >= -1) && (value < addressList.Count))
                    address_Selection_Combo.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("AddressIndex", value,
                        "Index must be valid");
            }
        }
 

        private void AddressSelectorOkButton_Click(object sender, EventArgs e)
        {
            Address address = addressList[Address_Index];    //index
            AddressForm addressForm = new AddressForm();    // address dialog box
            addressForm.AddressName = address.Name; //changes address form name to the chosen
            addressForm.Address1 = address.Address1; //changes address form address 1 to the chosen
            addressForm.Address2 = address.Address2; //changes address form address 2 to the chosen
            addressForm.City = address.City; //changes city to the chosen
            addressForm.State = address.State; //changes state to the chosen
            addressForm.ZipText = address.Zip.ToString(); //changes zip to the chosen

            DialogResult result = addressForm.ShowDialog(); // Shows form as dialog
            if (result == DialogResult.OK)
            {
                int zip; // variable for zip
                address.Name = addressForm.AddressName; //changes address form name to the chosen
                address.Address1 = addressForm.Address1; //changes address form address 1 to the chosen
                address.Address2 = addressForm.Address2; //changes address form address 2 to the chosen
                address.City = addressForm.City; //changes city to the chosen
                address.State = addressForm.State;//changes state to the chosen
                int.TryParse(addressForm.ZipText, out zip); // parse
                address.Zip = zip;//changes zip to the chosen
                Close();//closes form
            }
        }

        private void AddressSelectorCancelButton_Click(object sender, EventArgs e)
        {
            this.Close(); // closes the form
        }

        private void AddressSeclectionCombo_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(address_Selection_Combo, "");
        }

        private void AddressSeclectionCombo_Validating(object sender, CancelEventArgs e)
        {
            if (address_Selection_Combo.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider.SetError(address_Selection_Combo, "Select an Address");
            }
        }

        private void Address_Selection_Form_Load(object sender, EventArgs e)
        {
            foreach (Address a in addressList)
            {
                address_Selection_Combo.Items.Add(a.Name); //address box is loaded with address names
            }
        }
    }
}
