﻿namespace Prog2
{
    partial class Address_Selection_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addressSelectorLabel = new System.Windows.Forms.Label();
            this.address_Selection_Combo = new System.Windows.Forms.ComboBox();
            this.addressSelectorOkButton = new System.Windows.Forms.Button();
            this.addressSelectorCancelButton = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // addressSelectorLabel
            // 
            this.addressSelectorLabel.AutoSize = true;
            this.addressSelectorLabel.Location = new System.Drawing.Point(100, 84);
            this.addressSelectorLabel.Name = "addressSelectorLabel";
            this.addressSelectorLabel.Size = new System.Drawing.Size(120, 13);
            this.addressSelectorLabel.TabIndex = 0;
            this.addressSelectorLabel.Text = "Choose Address to Edit:";
            // 
            // address_Selection_Combo
            // 
            this.address_Selection_Combo.FormattingEnabled = true;
            this.address_Selection_Combo.Location = new System.Drawing.Point(103, 101);
            this.address_Selection_Combo.Name = "address_Selection_Combo";
            this.address_Selection_Combo.Size = new System.Drawing.Size(121, 21);
            this.address_Selection_Combo.TabIndex = 1;
            this.address_Selection_Combo.Validating += new System.ComponentModel.CancelEventHandler(this.AddressSeclectionCombo_Validating);
            this.address_Selection_Combo.Validated += new System.EventHandler(this.AddressSeclectionCombo_Validated);
            // 
            // addressSelectorOkButton
            // 
            this.addressSelectorOkButton.Location = new System.Drawing.Point(66, 153);
            this.addressSelectorOkButton.Name = "addressSelectorOkButton";
            this.addressSelectorOkButton.Size = new System.Drawing.Size(75, 23);
            this.addressSelectorOkButton.TabIndex = 2;
            this.addressSelectorOkButton.Text = "OK";
            this.addressSelectorOkButton.UseVisualStyleBackColor = true;
            this.addressSelectorOkButton.Click += new System.EventHandler(this.AddressSelectorOkButton_Click);
            // 
            // addressSelectorCancelButton
            // 
            this.addressSelectorCancelButton.Location = new System.Drawing.Point(184, 153);
            this.addressSelectorCancelButton.Name = "addressSelectorCancelButton";
            this.addressSelectorCancelButton.Size = new System.Drawing.Size(75, 23);
            this.addressSelectorCancelButton.TabIndex = 3;
            this.addressSelectorCancelButton.Text = "Cancel";
            this.addressSelectorCancelButton.UseVisualStyleBackColor = true;
            this.addressSelectorCancelButton.Click += new System.EventHandler(this.AddressSelectorCancelButton_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // Address_Selection_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 270);
            this.Controls.Add(this.addressSelectorCancelButton);
            this.Controls.Add(this.addressSelectorOkButton);
            this.Controls.Add(this.address_Selection_Combo);
            this.Controls.Add(this.addressSelectorLabel);
            this.Name = "Address_Selection_Form";
            this.Text = "Address Selection Form";
            this.Load += new System.EventHandler(this.Address_Selection_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addressSelectorLabel;
        private System.Windows.Forms.ComboBox address_Selection_Combo;
        private System.Windows.Forms.Button addressSelectorOkButton;
        private System.Windows.Forms.Button addressSelectorCancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}